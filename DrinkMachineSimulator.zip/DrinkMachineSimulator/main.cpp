#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>

using namespace std;
const int NUM_OPTIONS = 5;
void displayVentas(double);


struct VendingMachine{
string name;
double cost;
int numLeft;
};


int main()
{


    VendingMachine maquinaUno[NUM_OPTIONS];

    ifstream archivo;
    archivo.open("DrinkMachineInventory.txt");

   // double ventasTotales;

    if(!archivo){
        cout << "Trouble locating the file.\nExiting...";
        exit(EXIT_FAILURE);
    }

//    for(int i = 0; i<NUM_OPTIONS; i++){
  //      getline(archivo, maquinaUno[i].name, ',');
    //    getline(archivo, maquinaUno[i].cost, ',');
      //  getline(archivo, maquinaUno[i].numLeft);
//    }


//I decided to hard code the data as reading the file was creating problems for me.

    maquinaUno[0].name = "Coca-cola";
    maquinaUno[0].cost = 0.75;
    maquinaUno[0].numLeft = 20;

    maquinaUno[1].name = "Root Beer";
    maquinaUno[1].cost = 0.75;
    maquinaUno[1].numLeft = 20;

    maquinaUno[2].name = "Sprite";
    maquinaUno[2].cost = 0.75;
    maquinaUno[2].numLeft = 20;

    maquinaUno[3].name = "Spring Water";
    maquinaUno[3].cost = 0.80;
    maquinaUno[3].numLeft = 20;

    maquinaUno[4].name = "Apple Juice";
    maquinaUno[4].cost = 0.95;
    maquinaUno[4].numLeft = 20;

    int selection, choice;
    double payment, change, balance;
    double totalSales=0;

    cout << "Please enter 1 to start. " << endl;
    cin >> selection;


    while(selection == 1){
        cout << "Please select a drink or enter 0 to quit" << endl;
        for(int i =0; i < NUM_OPTIONS; i++){
            cout << (i+1)<< " " << maquinaUno[i].name << endl;}

        cin >> choice;


        if(choice == 0){
             cout << "Bye ";
            return 0;}
        else if(choice > 0 || choice < 6){
            cout << "Please enter how much money you will enter to the machine: " << endl;
            cin >> payment;}





        while(payment > 1 || payment < 0){
            cout << "You must enter a value greater than 0 but no greater than 1." << endl;
            cout << "Please enter how much money you will enter to the machine: " << endl;
            cin >> payment;}

        change = payment - maquinaUno[choice-1].cost;
        cout << "Your change is: " << change << endl;
        maquinaUno[choice-1].numLeft--;
        cout << "The number of items left is: " << maquinaUno[choice-1].numLeft << endl;
        balance = payment - change;
        totalSales += balance;

        displayVentas(totalSales);


    }












    return 0;
}


void displayVentas(double ventas){
cout << "Total sale was: " << ventas << endl;
cout << "Please make another selection or quit"<< endl;
cout << "-------------------------------------"<< endl;
}

